// routes/swapRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const { requestSwap, getMySwaps } = require('../controllers/swapController');

router.post('/', auth, requestSwap);
router.get('/', auth, getMySwaps);

module.exports = router;