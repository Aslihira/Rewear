// routes/itemRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const multer = require('multer');
const { addItem, getItems, getItem } = require('../controllers/itemController');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});

const upload = multer({ storage });

router.get('/', getItems);
router.post('/', auth, upload.single('image'), addItem);
router.get('/:id', getItem);

module.exports = router;